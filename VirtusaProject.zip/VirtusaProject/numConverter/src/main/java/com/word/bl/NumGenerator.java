package com.word.bl;

public class NumGenerator {
	
	public static String numGenerate(int n) {
		
		
		
		return null;
	}
	
	public int getFirstNum(int n) {
		
		while(n>=10 ) {
			n=n/10;
		}
		
		return n;
	}
public int getTwoNum(int n) {
		
		while(n>=100 ) {
			n=n/10;
		}
		return n;
	}

}
