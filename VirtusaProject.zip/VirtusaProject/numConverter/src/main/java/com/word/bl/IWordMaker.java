package com.word.bl;

public interface IWordMaker {

	String makeWord(int num);
}
