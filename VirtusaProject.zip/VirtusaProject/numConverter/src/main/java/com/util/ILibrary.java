package com.util;

public interface ILibrary {

	String wordLibrary(int num);
}
